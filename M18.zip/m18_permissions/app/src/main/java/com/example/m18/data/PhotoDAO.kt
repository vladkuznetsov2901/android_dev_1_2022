package com.example.m18.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PhotoDAO {

    @Query("SELECT * FROM photoSRC")
    fun getAllPhotos(): Flow<List<Photo>>

    @Insert(entity = Photo::class)
    fun insert(photo: Photo)

}