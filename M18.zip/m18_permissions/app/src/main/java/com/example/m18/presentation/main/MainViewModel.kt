package com.example.m18.presentation.main

import androidx.lifecycle.ViewModel
import com.example.m18.data.Photo
import com.example.m18.data.PhotoDAO
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainViewModel(private val photoDAO: PhotoDAO) : ViewModel() {

    val allPhotos = this.photoDAO.getAllPhotos()
    suspend fun insertPhoto(photo: Photo) {
        withContext(Dispatchers.IO) {
            photoDAO.insert(photo)
        }
    }





}